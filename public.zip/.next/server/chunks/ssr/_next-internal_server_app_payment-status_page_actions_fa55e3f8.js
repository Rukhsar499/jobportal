module.exports=[36036,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_payment-status_page_actions_fa55e3f8.js.map