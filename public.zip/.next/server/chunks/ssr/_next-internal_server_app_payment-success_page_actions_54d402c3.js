module.exports=[71830,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_payment-success_page_actions_54d402c3.js.map