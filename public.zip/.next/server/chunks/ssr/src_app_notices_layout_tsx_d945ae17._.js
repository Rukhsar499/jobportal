module.exports=[98615,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Notice",description:"Notice"}])}];

//# sourceMappingURL=src_app_notices_layout_tsx_d945ae17._.js.map