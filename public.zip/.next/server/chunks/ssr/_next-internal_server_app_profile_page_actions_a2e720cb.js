module.exports=[10519,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_profile_page_actions_a2e720cb.js.map