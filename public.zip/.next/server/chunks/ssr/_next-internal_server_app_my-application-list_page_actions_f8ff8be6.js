module.exports=[35732,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-application-list_page_actions_f8ff8be6.js.map