module.exports=[60208,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_results_page_actions_c0a88dc1.js.map