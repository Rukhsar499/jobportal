module.exports=[39429,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_notices_page_actions_97a1be8e.js.map