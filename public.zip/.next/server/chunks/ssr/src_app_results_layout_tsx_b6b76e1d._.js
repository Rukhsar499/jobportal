module.exports=[49586,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Result",description:"Result"}])}];

//# sourceMappingURL=src_app_results_layout_tsx_b6b76e1d._.js.map