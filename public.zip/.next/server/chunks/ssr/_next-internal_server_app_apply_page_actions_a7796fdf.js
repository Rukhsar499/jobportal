module.exports=[8123,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_apply_page_actions_a7796fdf.js.map