module.exports=[13923,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Apply For Job",description:"Apply For Job"}])}];

//# sourceMappingURL=src_app_apply_layout_tsx_654a0f93._.js.map