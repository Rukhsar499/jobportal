module.exports=[25309,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proxy_route_actions_caa765c7.js.map