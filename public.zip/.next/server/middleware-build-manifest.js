globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/95f7e5934dbb0e5d.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/023d923a37d494fc.js",
    "static/chunks/497f7b5edc7d3fce.js",
    "static/chunks/turbopack-bc36aecd6007e37c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];