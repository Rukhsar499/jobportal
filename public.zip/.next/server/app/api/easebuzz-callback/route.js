var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/easebuzz-callback/route.js")
R.c("server/chunks/[root-of-the-server]__38f7821e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_easebuzz-callback_route_actions_b8e1d873.js")
R.m(81738)
module.exports=R.m(81738).exports
