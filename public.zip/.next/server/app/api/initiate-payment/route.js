var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/initiate-payment/route.js")
R.c("server/chunks/[root-of-the-server]__2aa1e853._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_initiate-payment_route_actions_a1b4d6e4.js")
R.m(86700)
module.exports=R.m(86700).exports
