var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/route.js")
R.c("server/chunks/[root-of-the-server]__baf7bad7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_proxy_route_actions_caa765c7.js")
R.m(69687)
module.exports=R.m(69687).exports
